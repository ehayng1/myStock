export const iconPath = [
  { src: require("../data/" + 0 + ".png") },
  { src: require("../data/" + 1 + ".png") },
  { src: require("../data/" + 2 + ".png") },
];
