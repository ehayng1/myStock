import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  ScrollView,
  Image,
} from "react-native";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { MaterialIcons } from "@expo/vector-icons";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { Dimensions } from "react-native";
import StockTab from "./Screens/Stock";
import Home from "./Screens/Home";
import TradeTab from "./Screens/Trade";
import Leaderboard from "./Screens/Leaderboard";
import Resources from "./Screens/Resources";
import About from "./Screens/Drawer/About";
import Login from "./Screens/Login";
import SignUp from "./Screens/SignUp";
const screenWidth = Dimensions.get("window") * 0.3;
const Tab = createBottomTabNavigator();
const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: "#D84315",
    background: "white",
  },
};

function MyTabs({ navigation, route }) {
  // console.log("nav: ", navigation);
  // console.log("route: ", route);
  return (
    <Tab.Navigator
      initialRouteName="Feed"
      screenOptions={{
        tabBarActiveTintColor: "#E64A19",
      }}
    >
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          // headerShown: false,
          tabBarLabel: "Home",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Stock"
        component={StockTab}
        options={{
          headerShown: false,
          tabBarLabel: "Stock",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="chart-timeline-variant"
              color={color}
              size={size}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Trade"
        component={TradeTab}
        options={{
          headerShown: false,
          tabBarLabel: "Trade",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="swap-vertical"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Leaderboard"
        component={Leaderboard}
        options={{
          tabBarLabel: "Leaderboard",
          // headerShown: false,
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="leaderboard" size={size} color={color} />
          ),
        }}
      />

      <Tab.Screen
        name="Resources"
        component={Resources}
        options={{
          // headerShown: false,
          tabBarLabel: "Resources",
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="paperclip"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

const Drawer = createDrawerNavigator();

function MyDrawer() {
  return (
    <Drawer.Navigator
      screenOptions={({ navigation }) => ({
        // drawerIcon: ({ size, color }) => (
        //   <MaterialCommunityIcons name="menu" color="blue" size={size} />
        // ),
        headerLeft: () => (
          <MaterialCommunityIcons
            name="menu"
            color="#D84315"
            size={25}
            style={{ marginLeft: 10 }}
            onPress={navigation.toggleDrawer}
          />
        ),
        // drawerActiveTintColor: "black",
      })}
    >
      <Drawer.Screen
        name="Home"
        component={MyTabs}
        options={{
          drawerIcon: ({ size }) => (
            <MaterialCommunityIcons name="home" color="#E64A19" size={size} />
          ),
          drawerLabel: "Home",
          title: "DREAM",
          headerTitle: (props) => <LogoTitle {...props} />,
        }}
      />
      <Drawer.Screen
        name="About Us"
        component={About}
        options={{ drawerLabel: "About Us" }}
      />
      <Drawer.Screen
        name="Login"
        component={Login}
        options={{
          drawerLabel: "Login / Sign Up",
        }}
      />
      <Drawer.Screen
        name="SignUp"
        component={SignUp}
        options={{
          drawerLabel: "Sign Up",
          drawerItemStyle: { height: 0 },
        }}
      />
    </Drawer.Navigator>
  );
}

function LogoTitle() {
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
      }}
    >
      <Text style={{ marginLeft: "40%", fontWeight: 700, fontSize: 18 }}>
        DREAM
      </Text>
      <Image
        style={{
          marginLeft: "40%",
          width: 40,
          height: 40,
          borderRadius: 15,
        }}
        source={require("./data/logo.png")}
      />
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer theme={MyTheme}>
      <MyDrawer>
        <MyTabs />
      </MyDrawer>
      {/* <MyTabs></MyTabs> */}
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
