import React, { useState, useEffect } from "react";
import StockCard from "./StockCard";
import fetchStockInfo from "./fetchStockInfo";

const options = {
  method: "GET",
  headers: {
    // "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
    "X-RapidAPI-Key": "657a931109mshf4f8a24bbadc8d3p18d290jsn448ebbfa3f25",
    "X-RapidAPI-Host": "yh-finance.p.rapidapi.com",
  },
};
export default function PaintStock(prop) {
  let stockInfo = fetchStockInfo(prop.symbol);

  return (
    <StockCard
      nav={prop.nav}
      symbol={stockInfo[0]}
      price={stockInfo[1]}
      percent={stockInfo[3]}
    ></StockCard>
  );
}
