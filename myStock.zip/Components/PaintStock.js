import fetchStockInfo from "./fetchStockInfo";
import StockCard from "./StockCard";

export default function PaintStock(symbol) {
  let stock = fetchStockInfo(symbol);
  console.log("I am Paint!:", stock);
  return (
    <StockCard
      symbol={stock[0]}
      price={stock[1]}
      percent={stock[3]}
    ></StockCard>
  );
}
