export default function fetcher(Symbol) {
  const options = {
    method: "GET",
    headers: {
      "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
      "X-RapidAPI-Host": "yh-finance.p.rapidapi.com",
    },
  };

  fetch(
    "https://yh-finance.p.rapidapi.com/stock/v2/get-summary?symbol=" +
      Symbol +
      "&region=US",
    options
  )
    .then((response) => response.json())
    .then((response) => {
      console.log("res", response);
    })
    .catch((err) => console.error(err));
}
