// import { StyleSheet, Text, View, Pressable } from "react-native";
// import React, { useState, useEffect } from "react";

// const API_KEY = "OO2OADYEAGG4V90D";
// const finnhub = require("finnhub");
// const api_key = finnhub.ApiClient.instance.authentications["api_key"];
// api_key.apiKey = "cfvvpm1r01qmgsjq9l0gcfvvpm1r01qmgsjq9l10";
// const finnhubClient = new finnhub.DefaultApi();

// const options = {
//   method: "GET",
//   headers: {
//     // "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
//     "X-RapidAPI-Key": "657a931109mshf4f8a24bbadc8d3p18d290jsn448ebbfa3f25",
//     "X-RapidAPI-Host": "yh-finance.p.rapidapi.com",
//   },
// };
// const [stockInfo, setStock] = React.useState([]);

// export default function fetchStockInfo({ symbol }) {
//   // const [percent, setPercent] = React.useState();
//   // const [amount, setAmount] = React.useState(0);
//   let API_Symbol = symbol;

//   // finnhubClient.quote(API_Symbol, (error, data, response) => {
//   //   if (error) {
//   //     console.error(error);
//   //   } else {
//   //     // fetching the price
//   //     setPrice(data.c);
//   //     // fetch & calculating the percentage
//   //     let percent = ((price - data.pc) / data.pc) * 100;
//   //     setPercent(Math.round(percent * 100) / 100);
//   //   }
//   // });

//   // stock = [API_Symbol, price, percent];
//   // stock = [API_Symbol];
//   let stock = [];
//   async function fetchData(symbol) {
//     await fetch(
//       "https://yh-finance.p.rapidapi.com/stock/v2/get-summary?symbol=" +
//         symbol +
//         "&region=US",
//       options
//     )
//       .then((response) => response.json())
//       .then((response) => {
//         // console.log("resp", response);
//         stock[0] = API_Symbol;
//         // stock.push(API_Symbol);
//         // stock.push(response.financialData.currentPrice.fmt);
//         // stock.push(response.summaryDetail.previousClose.fmt);
//         stock[1] = response.financialData.currentPrice.fmt;
//         stock[2] = response.summaryDetail.previousClose.fmt;
//         let percent = ((stock[1] - stock[2]) / stock[2]) * 100;
//         stock[3] = Math.round(percent * 100) / 100;
//         // stock.push(Math.round(percent * 100) / 100);
//         // stock.push(response.price.longName);
//         stock[4] = response.price.longName;
//         stock[5] = response.price.shortName;
//         stock[6] = response.summaryDetail.dayLow.fmt;
//         stock[7] = response.summaryDetail.dayHigh.fmt;
//         stock[8] = response.summaryDetail.open.fmt;
//         stock[9] = response.summaryDetail.fiftyTwoWeekLow.fmt;
//         stock[10] = response.summaryDetail.fiftyTwoWeekHigh.fmt;
//         // console.log(stock);
//         setStock(stock);
//       })
//       .catch((err) => console.error(err));
//   }

//   useEffect(() => {
//     fetchData(symbol);
//   }, []);
//   // setStock(stock);
//   console.log("Stock: ", stockInfo);
//   // return stockInfo;
//   return stockInfo;
// }

import { StyleSheet, Text, View, Pressable } from "react-native";
import React, { useState } from "react";

const API_KEY = "OO2OADYEAGG4V90D";
const finnhub = require("finnhub");
const api_key = finnhub.ApiClient.instance.authentications["api_key"];
api_key.apiKey = "cfvvpm1r01qmgsjq9l0gcfvvpm1r01qmgsjq9l10";
const finnhubClient = new finnhub.DefaultApi();

export default function fetchStockInfo({ symbol }) {
  const [price, setPrice] = React.useState();
  const [percent, setPercent] = React.useState();
  const [amount, setAmount] = React.useState(0);
  let API_Symbol = symbol;
  let API_Call =
    "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=" +
    API_Symbol +
    "&apikey=" +
    API_KEY;
  let Xvalues = [];
  let Yvalues = [];

  finnhubClient.quote(symbol, (error, data, response) => {
    if (error) {
      console.error(error);
    } else {
      // fetching the price
      setPrice(data.c);
      // fetch & calculating the percentage
      let percent = ((price - data.pc) / data.pc) * 100;
      setPercent(Math.round(percent * 100) / 100);
    }
  });

  // x and y values
  fetch(API_Call)
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      for (var key in data["Time Series (Daily)"]) {
        Xvalues.push(key);
        Yvalues.push(data["Time Series (Daily)"][key]["2. high"]);
      }
    });
  stock = [API_Symbol, price, percent, Xvalues, Yvalues];
  console.log(stock);
  return stock;
}
