import {
  Button,
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
} from "react-native";
import PaintTransctions from "../Components/PaintTransactions";
import { LineChart } from "react-native-chart-kit";
import { Dimensions } from "react-native";
import { db } from "../firebaseConfig";
import {
  collection,
  onSnapShot,
  where,
  query,
  doc,
  addDoc,
  setDoc,
  getDocs,
  getDoc,
  updateDoc,
} from "firebase/firestore";
import React, { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const screenWidth = Dimensions.get("window").width * 0.95;
const color = "E64A19";

export default function Home() {
  const [userData, setUserData] = React.useState({
    balance: 0,
    balanceHistory: [0, 0, 0],
    profit: 0,
  });
  const [historyData, setHistoryData] = React.useState([
    { symbol: "", amount: 0, price: 0, balance: 0 },
  ]);
  let uniqueId;
  // const [balanceHistory, setbalanceHistory] = React.useState([])

  const getUserData = async () => {
    const docRef = doc(db, "purchaseHistory", uniqueId);
    const docSnap = await getDoc(docRef);
    docData = docSnap.data();
    if (docSnap.exists()) {
      setHistoryData(docData.history.reverse());
    } else {
      console.log("No such document!");
    }
    const userRef = doc(db, "users", uniqueId);
    const userSnap = await getDoc(userRef);
    console.log("Data: ", userSnap.data());
    if (userSnap.exists()) {
      setUserData({ ...userSnap.data() });
    } else {
      // doc.data() will be undefined in this case
      console.log("No such document!");
    }
  };
  const getId = async () => {
    uniqueId = await AsyncStorage.getItem("uniqueId");
    console.log("Unique ID:", uniqueId);
  };

  useEffect(() => {
    const init = async () => {
      await getId();
      await getUserData();
    };
    init();
  }, []);

  const chartConfig = {
    backgroundGradientFrom: "#FFFFFF",
    backgroundGradientFromOpacity: 0,
    backgroundGradientTo: "#FFFFFF",
    backgroundGradientToOpacity: 0,
    color: (opacity = 0) => `rgba(0, 0, 0, ${opacity})`, // color of label
    strokeWidth: 2, // optional, default 3
    barPercentage: 0.5,

    fillShadowGradientFrom: "#1d8038", // green
    // fillShadowGradientFrom: "#d93025", // red
    fillShadowGradientTo: "#FFFFFF",
  };
  // data for charts
  const data = {
    // labels: ["January", "February", "March", "April", "May", "June"],
    datasets: [
      {
        // data: [1000, 1234, 1232, 882, 988, 989, 872, 989, 1192, 1222],
        data: userData.balanceHistory,
        // color: (opacity = 0) => `rgba(217, 48, 37, ${opacity})`, // red
        color: (opacity = 0) => `rgba(29,128,56, ${opacity})`, // green
        strokeWidth: 2, // optional
      },
      // {
      //   data: [440, 220, 450, 220, 1200, 780, 872, 1250, 1192, 560],
      //   // color: (opacity = 0) => `rgba(217, 48, 37, ${opacity})`, // red
      //   color: (opacity = 0) => `rgba(217, 48, 37, ${opacity})`, // green
      //   strokeWidth: 2, // optional
      // },
    ],
  };

  let index = [];
  // console.log("What: ", userData);
  for (let i = 0; i < userData.balanceHistory.length; i++) {
    index.push(i);
  }

  return (
    <ScrollView>
      <View style={{ marginLeft: 20 }}></View>
      <View style={{ marginHorizontal: 10 }}>
        <Text
          style={{
            fontSize: 30,
            marginTop: 10,
            fontWeight: "600",
            marginBottom: 15,
            marginLeft: 5,
            color: "#D84315",
          }}
        >
          Hello, John
        </Text>
        <View style={{ marginTop: 10 }}>
          <Text style={{ color: "#808080", fontSize: 14 }}>
            Current Balance
          </Text>
          <Text
            style={{
              fontSize: 24,
              marginTop: 10,
              fontWeight: "600",
              marginBottom: 20,
              marginLeft: 5,
              color: "#D84315",
            }}
          >
            {/* $ {userData[0].balance} */}$ {userData.balance}
          </Text>
        </View>
        <View style={{ alignItems: "center", marginTop: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "500", marginBottom: 20 }}>
            Weekly Performance
          </Text>
          <LineChart
            data={data}
            width={screenWidth}
            height={256}
            verticalLabelRotation={30}
            chartConfig={chartConfig}
            hidePointsAtIndex={index}
            withInnerLines={false}
            withOuterLines={false}
            yAxisLabel="$"
            yLabelsOffset={0}
            bezier
          />
        </View>
        <View style={{ marginBottom: 15, marginTop: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "600" }}>
            Recent Transactions
          </Text>
        </View>
        {historyData.map(
          (el, index) =>
            index < 3 && (
              <PaintTransctions
                key={index}
                symbol={el.symbol}
                amount={el.amount * el.price}
              ></PaintTransctions>
            )
        )}
      </View>
    </ScrollView>
  );
}
