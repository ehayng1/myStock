import { StyleSheet, Text, View, ScrollView, Pressable } from "react-native";
import PaintTransctions from "../Components/PaintTransactions";
import { LineChart } from "react-native-chart-kit";
import { Dimensions } from "react-native";
import * as Application from "expo-application";
import { db } from "../firebaseConfig";
import {
  collection,
  onSnapShot,
  where,
  query,
  doc,
  addDoc,
  setDoc,
  getDocs,
  getDoc,
  updateDoc,
} from "firebase/firestore";
import { async } from "@firebase/util";
import React, { useState, useEffect } from "react";

const screenWidth = Dimensions.get("window").width * 0.95;
const color = "E64A19";
const chartConfig = {
  backgroundGradientFrom: "#FFFFFF",
  backgroundGradientFromOpacity: 0,
  backgroundGradientTo: "#FFFFFF",
  backgroundGradientToOpacity: 0,
  color: (opacity = 0) => `rgba(0, 0, 0, ${opacity})`, // color of label
  strokeWidth: 2, // optional, default 3
  barPercentage: 0.5,

  fillShadowGradientFrom: "#1d8038", // green
  // fillShadowGradientFrom: "#d93025", // red
  fillShadowGradientTo: "#FFFFFF",
};
const data = {
  // labels: ["January", "February", "March", "April", "May", "June"],
  datasets: [
    {
      data: [1000, 1234, 1232, 882, 988, 989, 872, 989, 1192, 1222],
      // color: (opacity = 0) => `rgba(217, 48, 37, ${opacity})`, // red
      color: (opacity = 0) => `rgba(29,128,56, ${opacity})`, // green
      strokeWidth: 2, // optional
    },
  ],
};

let index = [];
for (let i = 0; i < data.datasets[0].data.length; i++) {
  index.push(i);
}

export default function Home() {
  const [id, setId] = React.useState();
  let uniqueId = 0;
  const getUserId = async () => {
    const isIOS = Platform.OS === "ios";

    if (isIOS) {
      let iosId = await Application.getIosIdForVendorAsync();
      uniqueId = iosId;
      // setId(iosId);
    } else {
      uniqueId = Application.androidId;
    }
    console.log(uniqueId);
    // return uniqueId;
  };
  getUserId();
  console.log("ID: ", uniqueId);
  // console.log("ID: ", id);

  const ref = collection(db, "users");

  const getCollection = async () => {
    const q = query(collection(db, "cities"), where("capital", "==", true));

    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      console.log(doc.id, " => ", doc.data());
    });
  };

  const readData = async () => {
    const docRef = doc(db, "users", "123");
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
    } else {
      // doc.data() will be undefined in this case
      console.log("No such document!");
    }
  };
  // useEffect(() => {
  //   const read = async () => {
  //     // try {
  //     const docref = doc(db, "users", "123");
  //     const docSnap = await getDoc(docref);
  //     // console.log("Data: ", res.data());
  //     if (docSnap.exists()) {
  //       console.log("Document data:", docSnap.data());
  //     } else {
  //       // doc.data() will be undefined in this case
  //       console.log("No such document!");
  //     }
  //     //   console.log("Data: ", res);
  //     // } catch (e) {
  //     //   console.log(e);
  //     // }
  //   };
  //   read();
  // }, []);

  const setData = async () => {
    const docRef = collection(db, "cities");
    await setDoc(doc(docRef, "NY"), {
      name: "San Francisco",
      state: "CA",
      country: "USA",
      capital: false,
      population: 860000,
      regions: ["west_coast", "norcal"],
    });
  };

  const updateData = async () => {
    try {
      const res = await updateDoc(doc(db, "users", "123"), {
        balance: 1200,
      });
      console.log(res);
    } catch (e) {
      console.log(e);
    }
  };
  return (
    <ScrollView>
      {/* <Pressable onPress={addData}> */}
      <View style={{ marginLeft: 20 }}>
        <Pressable onPress={getCollection}>
          <Text>getCollection</Text>
        </Pressable>
        <Pressable onPress={updateData}>
          <Text>updateData</Text>
        </Pressable>
        <Pressable onPress={setData}>
          <Text>setData</Text>
        </Pressable>
        <Pressable onPress={readData}>
          <Text>readData</Text>
        </Pressable>
      </View>

      <View style={{ marginHorizontal: 10 }}>
        <View style={{ marginTop: 10 }}>
          <Text style={{ color: "#808080", fontSize: 14 }}>
            Current Balance
          </Text>
          <Text
            style={{
              fontSize: 26,
              marginTop: 10,
              fontWeight: "600",
              marginBottom: 20,
              marginLeft: 5,
              color: "#D84315",
            }}
          >
            $ 12,574.43
          </Text>
        </View>
        <View style={{ alignItems: "center", marginTop: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "500", marginBottom: 20 }}>
            Weekly Performance
          </Text>
          <LineChart
            data={data}
            width={screenWidth}
            height={256}
            verticalLabelRotation={30}
            chartConfig={chartConfig}
            hidePointsAtIndex={index}
            withInnerLines={false}
            withOuterLines={false}
            yAxisLabel="$"
            bezier
          />
        </View>
        <View style={{ marginBottom: 15, marginTop: 20 }}>
          <Text style={{ fontSize: 20, fontWeight: "600" }}>
            Recent Transactions
          </Text>
        </View>

        <PaintTransctions symbol="APPL"></PaintTransctions>
        <PaintTransctions symbol="IBM"></PaintTransctions>
      </View>
    </ScrollView>
  );
}
