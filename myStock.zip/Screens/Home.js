import { StyleSheet, Text, View, ScrollView } from "react-native";
import StockDetail from "../Components/StockDetail";
import fetcher from "../Components/fetch";
import fetchStockInfo from "../Components/fetchStockInfo";

export default function Home() {
  // fetchStockInfo()
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 10 }}>
        <View style={{ alignItems: "center", marginTop: 20 }}>
          <Text style={{ fontSize: 25, fontWeight: "bold" }}>
            Weekly Performance
          </Text>
        </View>
        {/* <StockChart        
        Symbol="AAPL"
        Range="5d"
        Interval="15min"  
      ></StockChart> */}
        <View style={{ marginBottom: 15, marginTop: 250 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Today Transactions
          </Text>
        </View>
        <StockDetail symbol="IBM"></StockDetail>
      </View>
    </ScrollView>
  );
}
