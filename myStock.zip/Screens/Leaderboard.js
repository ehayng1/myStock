import { StyleSheet, Text, Image, View, ScrollView } from "react-native";
import { Dimensions } from "react-native";
import { iconPath } from "../data/iconPath";
const screenWidth = Dimensions.get("window").width * 0.95;
export default function Leaderboard({ navigation }) {
  navigation.setOptions({ title: "Leaderboard" });
  // data.map((el) => {
  //   return el;
  // });

  const userData = [
    { name: "Jake", profit: 4444 },
    { name: "John", profit: 5555 },
    { name: "Jane", profit: 7777 },
    { name: "James", profit: 8888 },
    { name: "Abe", profit: 9999 },
  ];
  const topUser = [
    { name: "Second", profit: 2222 },
    { name: "First", profit: 1111 },
    { name: "Third", profit: 3333 },
  ];

  return (
    <>
      <View
        style={{
          backgroundColor: "#e8e2c2",
          height: "40%",
          borderBottomEndRadius: 30,
          borderBottomLeftRadius: 30,
        }}
      >
        <View
          style={{
            // marginTop: 65,
            flexDirection: "row",
            justifyContent: "space-around",
          }}
        >
          {/* <View>
            <Text>{topUser[0].name}</Text>
            <Text>{topUser[0].profit}</Text>
          </View>
          <View>
            <Text>{topUser[1].name}</Text>
            <Text>{topUser[1].profit}</Text>
          </View>
          <View>
            <Text>{topUser[2].name}</Text>
            <Text>{topUser[2].profit}</Text>
          </View> */}

          {/* {topUser.map((el, index) => (
            <View>
              <Text>{el.name}</Text>
              <Text>{el.profit}</Text>
            </View>
          ))} */}

          {topUser.map((el, index) => (
            <View
              key={new Date().getTime().toString()}
              style={[
                { marginTop: index === 1 ? 30 : 50 },
                { marginBottom: index === 1 ? 25 : 5 },
                // { paddingBottom: index === 1 ? 0 : 10 },
                {
                  flexDirection: "column",
                  paddingTop: 15,
                  paddingBottom: 10,
                  borderRadius: 20,
                  backgroundColor: "#ffbc76",
                },
              ]}
            >
              <Image
                style={{ width: 100, height: 100, marginBottom: 5 }}
                // source={require("../data/" + 1 + ".png")}
                source={iconPath[index].src}
                // source={require("../data/" + 2 + ".png")}
                // source={require(`../data/${index}.png`)}
              />
              <Text
                style={{
                  color: "#943210",
                  fontSize: 16,
                  fontWeight: "600",
                  textAlign: "center",
                }}
              >
                {el.name}
              </Text>
              <Text
                style={{
                  marginTop: 5,
                  color: "#540000",
                  fontSize: 12,
                  fontWeight: "400",
                  textAlign: "center",
                }}
              >
                $ {el.profit}
              </Text>
            </View>
          ))}
        </View>
      </View>
      <View style={{ marginTop: 15 }}>
        {userData.map((el, index) => (
          <View
            key={new Date().getTime().toString()}
            style={{
              flexDirection: "column",
            }}
          >
            <View
              style={{
                marginLeft: 20,
                marginHorizontal: 10,
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Text style={{ flex: 0.2, fontSize: 16, fontWeight: "600" }}>
                {index + 4}
              </Text>
              <Text style={{ flexGrow: 1, fontWeight: "500", fontSize: 18 }}>
                {el.name}
              </Text>
              <Text
                style={{
                  marginRight: 10,
                  fontWeight: "500",
                  fontSize: 16,
                  color: "#5A5A5A",
                }}
              >
                ${el.profit}
              </Text>
            </View>
            <View
              style={{
                height: 1,
                marginBottom: 15,
                marginTop: 15,
                backgroundColor: "#808080",
              }}
            ></View>
          </View>
        ))}
      </View>
    </>
    // <Text>Leaderboard</Text>
    // {data.map((el) => (
    //   <li>el</li>
    // ))}
  );
}
