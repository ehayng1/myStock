import { StyleSheet, Text, View, ScrollView } from "react-native";

export default function Leaderboard() {
  return <Text>Leaderboard</Text>;
}
