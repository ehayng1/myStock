import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
} from "react-native";
import fetchNewsInfo from "../Components/fetchNewsInfo";
import React, { useState, useEffect } from "react";
import CountDown from "react-native-countdown-component";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Week1 from "./Resources/Material";
import Week2 from "./Resources/Material";
import Week3 from "./Resources/Material";
import Week4 from "./Resources/Material";
import Week5 from "./Resources/Material";
import Week6 from "./Resources/Material";
import Week7 from "./Resources/Material";
import Week8 from "./Resources/Material";
import Week9 from "./Resources/Material";
import Week10 from "./Resources/Material";
import Week11 from "./Resources/Material";
import Week12 from "./Resources/Material";
import Week13 from "./Resources/Material";
import Week14 from "./Resources/Material";
import Week15 from "./Resources/Material";
import Week16 from "./Resources/Material";

import { color } from "react-native-elements/dist/helpers";
import AsyncStorage from "@react-native-async-storage/async-storage";

function Resource({ navigation }) {
  // const [newsInfo, setNewsInfo] = React.useState([]);
  const [stage, setStage] = React.useState(0);
  const [id, setId] = React.useState("12");
  // const [until, setUntil] = React.useState(0);
  const [timeLeft, setTimeLeft] = React.useState(0);

  const [material, setMaterial] = React.useState([
    { title: "Week 1", isActivated: true },
    { title: "Week 2", isActivated: false },
    { title: "Week 3", isActivated: false },
    { title: "Week 4", isActivated: false },
    { title: "Week 5", isActivated: false },
    { title: "Week 6", isActivated: false },
    { title: "Week 7", isActivated: false },
    { title: "Week 8", isActivated: false },
    { title: "Week 9", isActivated: false },
    { title: "Week 10", isActivated: false },
    { title: "Week 11", isActivated: false },
    { title: "Week 12", isActivated: false },
    { title: "Week 13", isActivated: false },
    { title: "Week 14", isActivated: false },
    { title: "Week 15", isActivated: false },
    { title: "Week 16", isActivated: false },
  ]);
  const options = {
    method: "POST",
    headers: {
      // 'X-RapidAPI-Key': '3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce',
      "X-RapidAPI-Key": "657a931109mshf4f8a24bbadc8d3p18d290jsn448ebbfa3f25",
      "X-RapidAPI-Host": "yh-finance.p.rapidapi.com",
    },
  };

  // let newsInfo = [];
  // useEffect(() => {
  //   fetch(
  //     "https://yh-finance.p.rapidapi.com/news/v2/list?region=US&snippetCount=5",
  //     options
  //   )
  //     .then((response) => response.json())
  //     .then((response) => {
  //       console.log(response);
  //       for (let i = 0; i < 5; i++) {
  //         let title = response.data.main.stream[i].content.title;
  //         let pubDate = response.data.main.stream[i].content.pubDate;
  //         let provider =
  //           response.data.main.stream[i].content.provider.displayName;
  //         let img =
  //           response.data.main.stream[i].content.thumbnail.resolutions[0].url;
  //         let id = response.data.main.stream[i].content.id;
  //         newsInfo[i] = [id, title, pubDate, provider, img];
  //       }
  //       console.log("Inside: ", newsInfo);
  //     })
  //     .catch((err) => console.error(err));
  //   console.log("Outside: ", newsInfo);
  // }, []);

  // let newsInfo = fetchNewsInfo();
  // console.log("Fetched", newsInfo);
  // console.log(newsInfo[0][0]);

  // const material = [
  //   { title: "Week 1", isActivated: false },
  //   { title: "Week 2", isActivated: false },
  //   { title: "Week 3", isActivated: false },
  //   { title: "Week 4", isActivated: false },
  //   { title: "Week 5", isActivated: false },
  //   { title: "Week 6", isActivated: false },
  //   { title: "Week 7", isActivated: false },
  //   { title: "Week 8", isActivated: false },
  //   { title: "Week 9", isActivated: false },
  //   { title: "Week 10", isActivated: false },
  //   { title: "Week 11", isActivated: false },
  //   { title: "Week 12", isActivated: false },
  //   { title: "Week 13", isActivated: false },
  //   { title: "Week 14", isActivated: false },
  //   { title: "Week 15", isActivated: false },
  //   { title: "Week 16", isActivated: false },
  // ];

  let initTime;
  // let timeLeft;
  useEffect(() => {
    const getData = async () => {
      try {
        const value = await AsyncStorage.getItem("timeKey");
        // if time value is previously stored
        if (value !== null) {
          let timeLeft;
          initTime = parseInt(value);
          let endTime = initTime + 604800000; // 604800 * 1000
          let curTime = new Date().getTime();
          // console.log("Initial Time: ", initTime);
          // console.log("End Time: ", endTime);
          // console.log("Current Time: ", curTime);
          timeLeft = endTime - curTime;
          timeLeft = Math.floor(timeLeft / 1000);
          console.log("Time Left: ", timeLeft);
          setTimeLeft(timeLeft);
          // updates the timer with new id
          setId(new Date().getTime().toString());
        }
        // when no key was found
        else {
          console.log("Store enterd");
          let time = new Date().getTime().toString();
          const storeData = async () => {
            try {
              await AsyncStorage.setItem("timeKey", time);
              console.log("Initial Date Recorded!", time);
            } catch (e) {
              console.log("Store failed: ", e);
            }
          };
          storeData();
        }
      } catch (e) {
        console.log("Read failed: ", e);
      }
    };
    getData();
  }, []);
  function handleFinish() {
    setMaterial(
      material.map((el, index) =>
        index === stage ? { title: el.title, isActivated: true } : el
      )
    );
    setStage(stage + 1);
    setId(new Date().getTime().toString());
  }

  return (
    <ScrollView>
      <View style={{}}>
        <Text
          style={{
            marginTop: 40,
            textAlign: "center",
            fontSize: 20,
            fontWeight: "600",
          }}
        >
          Until Next Material...
        </Text>
        <View style={{ marginTop: 40 }}>
          <CountDown
            id={id}
            until={timeLeft}
            onFinish={handleFinish}
            size={30}
            timeLabels={{ d: "Day", h: "Hour", m: "Min", s: "Sec" }}
            timeLabelStyle={{ color: "black", fontWeight: "500", fontSize: 14 }}
          />
        </View>
        <View style={{ marginTop: 40, alignContent: "center" }}>
          {material.map((element, index) => (
            <Pressable
              key={index}
              onPress={() => {
                if (element.isActivated) {
                  console.log(index, stage);
                  if (index === stage) {
                  }
                  return (
                    element.isActivated && navigation.navigate(element.title)
                  );
                }
              }}
            >
              <Text
                style={[
                  { color: element.isActivated ? "#296E85" : "#c0c0c0" },
                  {
                    textDecorationLine: "underline",
                    marginBottom: 25,
                    fontSize: 16,
                    textAlign: "center",
                  },
                ]}
              >
                {element.title}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const Stack = createNativeStackNavigator();
export default function Resources() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="Resource"
        component={Resource}
      />
      <Stack.Screen name="Week 1" component={Week1} />
      <Stack.Screen name="Week 2" component={Week2} />
      <Stack.Screen name="Week 3" component={Week3} />
      <Stack.Screen name="Week 4" component={Week4} />
      <Stack.Screen name="Week 5" component={Week5} />
      <Stack.Screen name="Week 6" component={Week6} />
      <Stack.Screen name="Week 7" component={Week7} />
      <Stack.Screen name="Week 8" component={Week8} />
      <Stack.Screen name="Week 9" component={Week9} />
      <Stack.Screen name="Week 10" component={Week10} />
      <Stack.Screen name="Week 11" component={Week11} />
      <Stack.Screen name="Week 12" component={Week12} />
      <Stack.Screen name="Week 13" component={Week13} />
      <Stack.Screen name="Week 14" component={Week14} />
      <Stack.Screen name="Week 15" component={Week15} />
      <Stack.Screen name="Week 16" component={Week16} />
    </Stack.Navigator>
  );
}

const style = StyleSheet.create({
  container: {
    paddingTop: 50,
  },
  tinyLogo: {
    width: 50,
    height: 50,
  },
  logo: {
    width: 100,
    borderRadius: 15,
    height: 100,
    alignContent: "flex-end",
  },
});
