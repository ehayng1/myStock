import { StyleSheet, Text, View, ScrollView } from "react-native";

export default function Resources() {
  return <Text>Resources</Text>;
}
