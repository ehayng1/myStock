import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
} from "react-native";

export default function Week1({ title, summary, audience, levelOfRisk }) {
  return (
    <View>
      <Text style={{ fontSize: 20, textAlign: "center", fontWeight: "600" }}>
        Day Trading
      </Text>
      <Text style={{ fontFamily: "Arial", fontWeight: "400", fontSize: 20 }}>
        Day trading - Day trading is a strategy where stocks and securities are
        traded on a daily basis, where investors exploit the daily volatility to
        earn money. Less risk present in the market as the trading term is
        pretty short. Has a relatively lower risk compared to other strategies.
      </Text>
      <Text>Audience: For beginners</Text>
    </View>
  );
}

function Week2({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week2</Text>;
}

function Week3({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week3</Text>;
}

function Week4({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week4</Text>;
}

function Week5({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week5</Text>;
}

function Week6({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week6</Text>;
}

function Week7({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week7</Text>;
}
function Week8({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week8</Text>;
}

function Week9({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week9</Text>;
}

function Week10({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week10</Text>;
}
function Week11({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week11</Text>;
}

function Week12({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week12</Text>;
}

function Week13({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week13</Text>;
}

function Week14({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week10</Text>;
}
function Week15({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week11</Text>;
}

function Week16({ navigation }) {
  return <Text style={{ fontWeight: "500", fontSize: 20 }}>Week12</Text>;
}
