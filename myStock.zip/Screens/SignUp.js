import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
// import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import { getFirestore, collection, addDoc } from "firebase/firestore";
import { db } from "../firebaseConfig";
const auth = getAuth();

export default function SignUp(props) {
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [name, setName] = useState("");
  const [nameError, setNameError] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [confirmPasswordError, setConfirmPasswordError] = useState("");
  const [loading, setLoading] = useState(false);

  const register = () => {
    if (email == "") {
      setEmailError("Please enter an email.");
      return;
    } else if (name == "") {
      setNameError("Please enter your name.");
      return;
    } else if (password == "") {
      setPasswordError("Please enter a password.");
      return;
    } else if (confirmPassword == "") {
      setConfirmPasswordError("Please confirm your password.");
      return;
    } else if (password != confirmPassword) {
      setConfirmPasswordError("Password does not match.");
      return;
    }
    setLoading(true);
    createUserWithEmailAndPassword(auth, email, password)
      .then(async (userCredential) => {
        console.log("The user account is created.");
        const docRef = await addDoc(collection(db, "Users"), {
          email: email,
          name: name,
        });
        props.navigation.reset({
          index: 0,
          routes: [{ name: "Login" }],
        });
        // props.navigation.navigate('Login')
        setLoading(false);
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        if (errorCode == "auth/email-already-in-use") {
          Toast.show({
            type: "error",
            text1: "Email is already used.",
          });
        } else if (errorCode == "auth/invalid-email") {
          Toast.show({
            type: "error",
            text1: "Email format is not correct.",
          });
        } else if (errorCode == "auth/invalid-email") {
          Toast.show({
            type: "error",
            text1: "Email format is not correct.",
          });
        } else if (errorCode == "auth/weak-password") {
          Toast.show({
            type: "error",
            text1: "Password is too weak.",
          });
        }
        setLoading(false);
      });
  };

  return (
    <View style={styles.container}>
      {/* <KeyboardAwareScrollView> */}
      <Text
        style={{
          fontSize: 40,
          fontWeight: "bold",
          marginLeft: 20,
          // marginTop: hp(20),
          marginTop: "20%",
        }}
      >
        Sign Up
      </Text>
      {/* <Input
        style={{
          backgroundColor: "#EEEEEE",
          padding: 15,
          fontSize: 15,
          marginTop: 50,
          borderRadius: 15,
        }}
        inputContainerStyle={{
          borderBottomWidth: 0,
        }}
        containerStyle={{
          // paddingHorizontal: hp(3),
          paddingHorizontal: "5%",
        }}
        autoCapitalize={"none"}
        placeholder="Email"
        onChangeText={setEmail}
        onChange={() => {
          setEmailError("");
        }}
        errorMessage={emailError}
      /> */}
      {/* <Input
          style={{
            backgroundColor: "#EEEEEE",
            padding: 15,
            fontSize: 15,
            borderRadius: 15,
          }}
          inputContainerStyle={{
            borderBottomWidth: 0,
          }}
          containerStyle={{
            paddingHorizontal: hp(3),
          }}
          placeholder="Name"
          onChangeText={setName}
          onChange={() => {
            setNameError("");
          }}
          errorMessage={nameError}
        />
        <Input
          style={{
            backgroundColor: "#EEEEEE",
            padding: 15,
            fontSize: 15,
            borderRadius: 15,
          }}
          inputContainerStyle={{
            borderBottomWidth: 0,
          }}
          containerStyle={{
            paddingHorizontal: hp(3),
          }}
          onChange={() => {
            setPasswordError("");
          }}
          secureTextEntry={true}
          autoCapitalize={"none"}
          placeholder="Password"
          onChangeText={setPassword}
          errorMessage={passwordError}
        />
        <Input
          style={{
            backgroundColor: "#EEEEEE",
            padding: 15,
            fontSize: 15,
            borderRadius: 15,
          }}
          inputContainerStyle={{
            borderBottomWidth: 0,
          }}
          containerStyle={{
            paddingHorizontal: hp(3),
          }}
          onChange={() => {
            setConfirmPasswordError("");
          }}
          secureTextEntry={true}
          autoCapitalize={"none"}
          placeholder="Confirm Password"
          onChangeText={setConfirmPassword}
          errorMessage={confirmPasswordError}
        /> */}
      <TouchableOpacity
        style={{
          backgroundColor: "#537FE7",
          marginLeft: 20,
          marginRight: 20,
          marginTop: 20,
          padding: 15,
          borderRadius: 15,
        }}
        onPress={() => {
          register();
        }}
      >
        {loading ? (
          <ActivityIndicator color={"white"} />
        ) : (
          <Text
            style={{
              fontSize: 15,
              textAlign: "center",
              fontWeight: "bold",
              color: "white",
            }}
          >
            Sign Up
          </Text>
        )}
      </TouchableOpacity>
      <Text
        style={{
          textAlign: "center",
          marginTop: 5,
        }}
      >
        Already have an account?
        <Text
          style={{ fontWeight: "bold" }}
          onPress={() => {
            props.navigation.navigate("Login");
          }}
        >
          {" "}
          Login
        </Text>
      </Text>
      {/* </KeyboardAwareScrollView> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "white",
  },
});
