import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  Pressable,
} from "react-native";
import React, { useState } from "react";
import PaintStock from "../Components/PaintStock";
import StockHeader from "../Components/StockHeader";
import SearchStock from "../Components/SearchBox";
import StockDetail from "../Components/StockDetail";
import fetchTrends from "../Components/fetchTrend";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const API_KEY = "OO2OADYEAGG4V90D";
const finnhub = require("finnhub");
const api_key = finnhub.ApiClient.instance.authentications["api_key"];
api_key.apiKey = "cfvvpm1r01qmgsjq9l0gcfvvpm1r01qmgsjq9l10";
const finnhubClient = new finnhub.DefaultApi();
const options = {
  method: "GET",
  headers: {
    // "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
    "X-RapidAPI-Key": "91b74585dfmsh52e3d564c3855b9p195ec6jsn593aceacdf1e",
    "X-RapidAPI-Host": "yahoo-finance15.p.rapidapi.com",
  },
};

function Stock({ navigation }) {
  // trend = fetchTrends()
  // trend[0][0] // popular 1
  // trend[1][0] // gainer 1
  // trend[2][0] // loser 1
  return (
    <ScrollView>
      <SearchStock nav={navigation}></SearchStock>
      <View style={{ marginHorizontal: 10 }}>
        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Most popular stocks
          </Text>
        </View>
        <StockHeader></StockHeader>
        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        {/* <PaintStock symbol="TSLA" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="AMZN" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="IBM"nav={navigation}></PaintStock> */}
        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Top gainers today
          </Text>
        </View>
        <StockHeader></StockHeader>
        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        {/* <PaintStock symbol="AAPL" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="HCM" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="META" nav={navigation}></PaintStock> */}
        <View style={{ marginBottom: 15, marginTop: 25 }}>
          <Text style={{ fontSize: 21, fontWeight: "bold" }}>
            Top losers today
          </Text>
        </View>
        <StockHeader></StockHeader>
        <View style={{ height: "0.1%", backgroundColor: "#808080" }}></View>
        {/* <PaintStock symbol="DSEY" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="GOOGL" nav={navigation}></PaintStock> */}
        {/* <PaintStock symbol="META" nav={navigation}></PaintStock> */}
      </View>
    </ScrollView>
  );
}
const Stack = createNativeStackNavigator();
export default function StockTab() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Stock" component={Stock} />
      <Stack.Screen
        name="StockDetail"
        component={StockDetail}
        options={{ title: "Stock Detail" }}
      />
    </Stack.Navigator>
  );
}
