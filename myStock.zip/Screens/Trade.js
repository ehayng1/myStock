import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  ScrollView,
} from "react-native";
import React, { useState, useEffect } from "react";
// import FetchStock from "../Components/FetchStock";
import {
  doc,
  addDoc,
  setDoc,
  getDoc,
  updateDoc,
  increment,
  arrayUnion,
} from "firebase/firestore";
import { db } from "../firebaseConfig";
import AsyncStorage from "@react-native-async-storage/async-storage";
import StockDetail from "../Components/StockDetail";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const styles = StyleSheet.create({
  card: {
    marginTop: 15,
    backgroundColor: "#f7e5df",
    borderRadius: 10,
  },
  font1: {
    fontSize: 18,
    fontWeight: "500",
  },
});

function Trade({ navigation }) {
  const [data, setData] = React.useState([{ symbol: "", amount: 0, price: 0 }]);
  let uniqueId;

  const getId = async () => {
    uniqueId = await AsyncStorage.getItem("uniqueId");
    console.log("Unique ID:", uniqueId);
  };

  const getUserData = async () => {
    const docRef = doc(db, "purchaseHistory", uniqueId);
    const docSnap = await getDoc(docRef);
    docData = docSnap.data();
    if (docSnap.exists()) {
      setData(docData.history);
    } else {
      console.log("No such document!");
    }
  };

  useEffect(() => {
    const init = async () => {
      await getId();
      await getUserData();
    };
    init();
  }, []);

  return (
    <ScrollView>
      <View style={{ marginHorizontal: 10 }}>
        <Text
          style={{
            marginBottom: 20,
            fontSize: 21,
            fontWeight: "bold",
            marginTop: 10,
          }}
        >
          Purchased Stocks
        </Text>

        <View style={{ flexDirection: "row" }}>
          <Text style={{ color: "#808080", flex: 0.4 }}>Asset</Text>
          <Text style={{ color: "#808080", flex: 0.4 }}>Purchased Price</Text>
          <Text style={{ color: "#808080", flex: 0.2 }}>Amount</Text>
        </View>
        <View
          style={{
            height: "0.1%",
            backgroundColor: "#808080",
            marginTop: 5,
            marginBottom: 15,
          }}
        ></View>

        <View>
          {data.map(
            (el, index) =>
              index < 10 && (
                <>
                  <Pressable
                    onPress={() =>
                      navigation.navigate("StockDetail", {
                        symbol: el.symbol,
                      })
                    }
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                    key={index}
                  >
                    <Text
                      style={{ flex: 0.4, fontWeight: "bold", fontSize: 18 }}
                    >
                      {el.symbol}
                    </Text>
                    <Text
                      style={{ flex: 0.4, fontWeight: "bold", fontSize: 16 }}
                    >
                      {" "}
                      $ {el.price}
                    </Text>
                    <View
                      style={{
                        flexDirection: "row",
                        flex: 0.2,
                        alignItems: "center",
                      }}
                    >
                      <Text style={{ fontSize: 16 }}> {el.amount}</Text>
                      <Text style={{ color: "#808080", fontSize: 12 }}>
                        {" "}
                        shares
                      </Text>
                    </View>
                  </Pressable>

                  <View
                    style={{
                      height: 0.4,
                      backgroundColor: "#808080",
                      marginTop: 15,
                      marginBottom: 15,
                    }}
                  ></View>
                </>
              )
          )}
        </View>
      </View>
    </ScrollView>
  );
}

const Stack = createNativeStackNavigator();
export default function TradeTab() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Trade" component={Trade} />
      <Stack.Screen
        name="StockDetail"
        component={StockDetail}
        options={{ title: "Stock Detail" }}
      />
    </Stack.Navigator>
  );
}
