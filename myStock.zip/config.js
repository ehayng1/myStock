export default options = {
  method: "GET",
  headers: {
    // "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
    "X-RapidAPI-Key": "91b74585dfmsh52e3d564c3855b9p195ec6jsn593aceacdf1e",
    "X-RapidAPI-Host": "apidojo-yahoo-finance-v1.p.rapidapi.com",
  },
};
